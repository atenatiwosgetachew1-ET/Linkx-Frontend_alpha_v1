import React, { useEffect, useState } from "react";
import { useBackgroundAnimations } from "../utils/backgroundAnimations.js";
import theme from "../themes/index.js";
import {
  compactValidationErrors,
  sanitizeIdentifier,
  sanitizeSecret,
  validateLoginPassword,
  validateRequiredIdentifier,
} from "../utils/inputSecurity.js";

const loginBackgroundVideo = import.meta.env.BASE_URL + theme.backgroundVideo;
const fallbackLoginBackgroundVideo = "/" + theme.backgroundVideo;
const loginBackgroundImage = import.meta.env.BASE_URL + theme.backgroundImage;
const fallbackLoginBackgroundImage = "/" + theme.backgroundImage;
const loginLogo = import.meta.env.BASE_URL + theme.logo;
const genericLoginError = "Unable to sign in at this time. Please try again later.";

export default function LoginPage({ onLogin, onParentProjectLogin, ssoError = "", isSsoAuthenticating = false }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const videoRef = React.useRef(null);
  const [videoSrc, setVideoSrc] = useState(loginBackgroundVideo);
  const [isVideoUnavailable, setIsVideoUnavailable] = useState(false);
  const [imageSrc, setImageSrc] = useState(loginBackgroundImage);
  const [isImageLoaded, setIsImageLoaded] = useState(false);
  const { areBackgroundAnimationsEnabled } = useBackgroundAnimations();

  const playBackgroundVideo = (videoElement = videoRef.current) => {
    if (!videoElement) return;
    videoElement.play?.().catch(() => {});
  };

  const handleVideoError = () => {
    if (videoSrc === loginBackgroundVideo) {
      setVideoSrc(fallbackLoginBackgroundVideo);
      return;
    }
    setIsVideoUnavailable(true);
  };

  const handleImageError = () => {
    if (imageSrc === loginBackgroundImage) {
      setIsImageLoaded(false);
      setImageSrc(fallbackLoginBackgroundImage);
    }
  };

  useEffect(() => {
    if (!areBackgroundAnimationsEnabled) return;
    setIsVideoUnavailable(false);
    setVideoSrc(loginBackgroundVideo);
    videoRef.current?.load?.();
    playBackgroundVideo();
  }, [areBackgroundAnimationsEnabled]);


  const handleParentProjectLogin = async () => {
    setError("");
    if (typeof onParentProjectLogin !== "function") {
      setError("Parent project login is not configured.");
      return;
    }

    setIsSubmitting(true);
    try {
      await onParentProjectLogin();
    } catch (err) {
      setError(err?.message || genericLoginError);
      setIsSubmitting(false);
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");

    const cleanUsername = sanitizeIdentifier(username, { maxLength: 120 }).trim();
    const cleanPassword = sanitizeSecret(password, { maxLength: 256 });
    const validationError = compactValidationErrors(
      validateRequiredIdentifier(cleanUsername, "Username", { minLength: 3, maxLength: 120 }),
      validateLoginPassword(cleanPassword),
    );

    if (validationError) {
      setError(validationError);
      return;
    }

    setIsSubmitting(true);

    try {
      await onLogin(cleanUsername, cleanPassword);
    } catch (err) {
      setError(err?.message || genericLoginError);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <main className="linkx_login_shell">
      {areBackgroundAnimationsEnabled && !isVideoUnavailable ? (
        <video
          key={videoSrc}
          ref={videoRef}
          className="linkx_login_video"
          autoPlay
          muted
          loop
          playsInline
          preload="auto"
          aria-hidden="true"
          onCanPlay={(event) => playBackgroundVideo(event.currentTarget)}
          onError={handleVideoError}
        >
          <source src={videoSrc} type="video/mp4" />
        </video>
      ) : (
        <img
          key={imageSrc}
          className={`linkx_login_video linkx_login_image${isImageLoaded ? " is-loaded" : ""}`}
          src={imageSrc}
          alt=""
          aria-hidden="true"
          decoding="async"
          fetchPriority="high"
          loading="eager"
          onLoad={() => setIsImageLoaded(true)}
          onError={handleImageError}
        />
      )}
      <div className="linkx_login_overlay" aria-hidden="true" />
      <div className="linkx_login_content">
      <section className="linkx_login_panel" aria-label="Login">
        <div className="linkx_login_brand">
          <div className="linkx_login_brand_mark">
            <img className="linkx_login_brand_logo" src={loginLogo} alt={`${theme.name} logo`} />
            <span>{theme.name}</span>
          </div>
          <small>{theme.tagline}</small>
        </div>
        <form className="linkx_login_form" onSubmit={handleSubmit} noValidate>
          <label>
            Username
            <input
              type="text"
              value={username}
              autoComplete="username"
              maxLength={120}
              aria-invalid={!!error}
              onChange={(event) => setUsername(sanitizeIdentifier(event.target.value, { maxLength: 120 }))}
              required
            />
          </label>
          <label>
            Password
            <input
              type="password"
              value={password}
              autoComplete="current-password"
              maxLength={256}
              aria-invalid={!!error}
              onChange={(event) => setPassword(sanitizeSecret(event.target.value, { maxLength: 256 }))}
              required
            />
          </label>
          {(error || ssoError) && <div className="linkx_login_error">{error || ssoError}</div>}
          <button type="submit" disabled={isSubmitting || isSsoAuthenticating}>
            {isSsoAuthenticating ? "Completing SSO..." : isSubmitting ? "Signing in..." : "Sign in"}
          </button>
          <div className="linkx_login_divider"><span>or</span></div>
          <button
            type="button"
            className="linkx_login_parent_project_btn"
            disabled={isSubmitting || isSsoAuthenticating}
            onClick={handleParentProjectLogin}
          >
            Continue with Parent project
          </button>
        </form>
      </section>
      </div>
      <footer className="linkx_login_footer" aria-label="Login footer">
        <p>{theme.copyright} {theme.footerNotice}</p>
      </footer>
    </main>
  );
}
